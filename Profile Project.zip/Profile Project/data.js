// data.js
const profiles = [
  {
    id: 1,
    name: "John Doe",
    address: "123 Main St, City1, Country1",
    latitude: 40.7128,
    longitude: -74.0060,
  },
  // Add more profiles here
];

export default profiles;